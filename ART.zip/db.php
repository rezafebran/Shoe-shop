<?php
    $con = mysqli_connect("localhost","id17543620_mm2021b","Ssip2021111-","id17543620_2021ssip");
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>
