<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/base/_custom.css">
    <link rel="stylesheet" href="./css/pages/_skeleton.css">
    <title>Shopping Cart | Home</title>
</head>
<body>
    <header id="header" class="header">
      <div class="container">
          <div class="flex__navbar">
              <div class="logo"><a href="#">Art - Shoe</a></div>
              <div class="logo"><a href="#">Login / Sign Up Here</a></div>
              <div class="shoppping__cart">
                  <ul>
                      <li class="sub__menu">
                          <img src="./css/img/cart.png" alt="">
                         <div id="shopping__list">
                             <table id="cart__content" class="full_width">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                             </table>
                             <a href="#" id="clear-cart" class="button u-full-width">Clear Cart</a>
                         </div>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
        </div>
        
    </header>
    <div id="banner">
        <div class="container">
            <div class="row">
             <div class="banner__container">
                 <div class="banner__content">
                    <h2 id="learn">Good shoe,Good Run</h2>
                    <form action="#" id="search" method="post" class="form">
                        <input class="u-full-width" type="text" placeholder="Find Shoe" id="search-course">
                        <input type="submit" id="submit-search-course" class="submit-search-course">
                    </form>
                 </div>
             </div>
            </div>
        </div>
    </div>
<section>
<div id="courses-list" class="container">
    <h1 id="heading" class="heading">Product</h1>
    <div class="row__content">
        <div class="four columns" id="grid__column">
            <div class="card">
                <img src="./css/img/yeezy.jpg" class="course-image_1">
                <div class="info-card">
                    <h4>Yeezy Grey </h4>
                    <p>new shoe not used shoe</p>
                    <img src="./css/img/stars.png">
                    <span class="u-pull-right ">$200</span></p>
                    <a href="#" class="u-full-width button-primary button input add-to-cart" data-id="1">Add to Cart</a>
                </div>
            </div> <!--.card-->
            <div class="four columns" id="grid__column">
                <div class="card">
                    <img src="./css/img/asic.jpg" class="course-image_1">
                    <div class="info-card">
                        <h4>Asic Tiger</h4>
                        <p>new shoe not used shoe</p>
                        <img src="./css/img/stars.png">
                        <span class="u-pull-right ">$200</span></p>
                        <a href="#" class="u-full-width button-primary button input add-to-cart" data-id="1">Add to Cart</a>
                    </div>
                </div> 
                <div class="four columns" id="grid__column">
                    <div class="card">
                        <img src="./css/img/jordan.jpg" class="course-image_1">
                        <div class="info-card">
                            <h4>Air jordan 2</h4>
                            <p>Second shoe like new</p>
                            <img src="./css/img/stars.png">
                            <span class="u-pull-right ">$250</span></p>
                            <a href="#" class="u-full-width button-primary button input add-to-cart" data-id="1">Add to Cart</a>
                        </div>
                    </div> 
                    <div class="four columns" id="grid__column">
                        <div class="card">
                            <img src="./css/img/black.jpg" class="course-image_1">
                            <div class="info-card">
                                <h4>Yeezy Black </h4>
                                <p>Seecond shoe like new</p>
                                <img src="./css/img/stars.png">
                                <span class="u-pull-right ">$300</span></p>
                                <a href="#" class="u-full-width button-primary button input add-to-cart" data-id="1">Add to Cart</a>
                            </div>
            </div>
    </div>
    </div>
    </section>
    <footer>
        
    <footer id="footer" class="footer">
        <div class="container">
            <div class="row">
                    <div class="four columns">
                            <nav id="primary" class="menu">
                                <a class="link" href="#">Mobile Applications</a>
                                <a class="link" href="#">Support</a>
                                <a class="link" href="#">Help</a>
                            </nav>
                    </div>
                    <div class="four columns">
                            <nav id="secondary" class="menu">
                                <a class="link" href="#">About Us</a>
                            </nav>
                    </div>
            </div>
        </div>
    </footer>
  <script src="./js/index.js"></script>
</body>
</html>