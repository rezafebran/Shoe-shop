-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 09, 2021 at 08:49 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id17543620_2021ssip`
--

-- --------------------------------------------------------

--
-- Table structure for table `art`
--

CREATE TABLE `art` (
  `id` int(11) NOT NULL,
  `username` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `create_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `art`
--

INSERT INTO `art` (`id`, `username`, `email`, `password`, `create_datetime`) VALUES
(2, 'eja', 'las@sds.sss', 'f71924e84caae58443187fb52d13a2b3', '2021-09-26 05:37:59'),
(3, 'Tito', 'Tito@art.com', '202cb962ac59075b964b07152d234b70', '2021-09-26 06:24:32'),
(4, '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/DzdTSv0728s\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'art@gmail.com', 'adcdbf2d0d8c4c9053256256831136cf', '2021-09-27 00:46:46'),
(5, '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/RtCdf_FtidI\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'exbaeno@gmail.com', '57f842286171094855e51fc3a541c1e2', '2021-09-27 00:55:09'),
(6, '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/diUO8AynYIg\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'ujefu@gmail.com', '6ab97dc5c706cfdc425ca52a65d97b0d', '2021-09-27 03:01:01'),
(10, '1', '1', 'c4ca4238a0b923820dcc509a6f75849b', '2021-10-04 02:23:42'),
(11, '2', '2', 'c81e728d9d4c2f636f067f89cc14862c', '2021-10-04 02:49:37'),
(12, '222', '222', '934b535800b1cba8f96a5d72f72f1611', '2021-10-09 07:22:27'),
(13, '222', '222', 'bcbe3365e6ac95ea2c0343a2395834dd', '2021-10-09 07:23:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `art`
--
ALTER TABLE `art`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `art`
--
ALTER TABLE `art`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
